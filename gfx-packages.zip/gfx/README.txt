VOIDCORE GFX PACK STRUCTURE

Put the actual game PAK files inside the matching profile folder.

Games:
- bgmi
- gl
- kr
- vn
- tw

Profiles:
- balanced
- high_fps
- ultra_fps
- reset

Example:
bgmi/balanced/your_file.pak
bgmi/high_fps/your_file.pak
bgmi/ultra_fps/your_file.pak
bgmi/reset/original_file.pak

The same structure is used for GL, KR, VN and TW.
Remove .gitkeep files if your GitHub upload does not need them.
